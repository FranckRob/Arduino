/*
 * main.c
 *
 * Created: 4/14/2022 2:24:15 PM
 * Author : FRANCOIS ROBICHAUD
 */ 

#include "./lib/clock/clock.h"
#include <avr/io.h>
#define F_CPU 16000000UL  
#include <util/delay.h>

int main (void){


	rtc_init();
	//rtc_setTime(0x16,0x10,0x00);	//16:10:00 (hh:mm:ss)
	//rtc_setDate(0x22,0x03,0x15);	//22-03-15 (yy-MM-dd)
	
	usart_init();

	while(1)
	{
		rtc_getDate(&year,&month,&day);
		usart_sendByte('2');
		usart_sendByte('0');
		usart_sendPackedBCD(year);
		usart_sendByte('-');
		usart_sendPackedBCD(month);
		usart_sendByte('-');
		usart_sendPackedBCD(day);
		usart_sendByte(' ');

		rtc_getTime(&hour,&min,&sec);
		usart_sendPackedBCD(hour);
		usart_sendByte(':');
		usart_sendPackedBCD(min);
		usart_sendByte(':');
		usart_sendPackedBCD(sec);
		usart_sendByte('\n');	//new line
		usart_sendByte('\r');	//carrier return

		_delay_ms(200);
	}
}



