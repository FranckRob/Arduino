/*
 * clock.c
 *
 * Created: 3/15/2022 3:39:24 PM
 * Author : FRANCOIS ROBICHAUD
 */ 

#include <avr/io.h>
#define F_CPU 16000000UL  
#include <util/delay.h>

void i2c_stop() {   	
	TWCR = (1<< TWINT)|(1<<TWEN)|(1<<TWSTO);
}
//*************************************************************
void i2c_write(unsigned char data){	
	TWDR = data ;
	TWCR = (1<< TWINT)|(1<<TWEN);
	while (!(TWCR & (1 <<TWINT)));
}

//************************************************************

unsigned char i2c_read(unsigned char ackVal)
{
	TWCR = (1<< TWINT)|(1<<TWEN)|(ackVal<<TWEA);
	while (!(TWCR & (1 <<TWINT)));
	return TWDR  ;
}

//*************************************************************
void i2c_start(void){   
    	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
    	while (!(TWCR & (1 << TWINT)));
}
//*************************************************************
void i2c_init(void){	
	TWSR=0x00;				//set prescaler bits  to zero
	TWBR=152;				//SCL freq. is 50k for XTAL=16M
	TWCR=0x04;				//enable TWI module
}

//************************************************************

void rtc_init(void)
{
	i2c_init();			//initialize I2C module
	i2c_start();		//transmit START condition
	i2c_write(0xD0);	//address DS1307 for write
	i2c_write(0x07);	//set register pointer to 7
	i2c_write(0x00);	//set value of location 7 to 0
	i2c_stop();			//transmit STOP condition
}

//************************************************************

void rtc_setTime(unsigned char h,unsigned char m,unsigned char s)
{
	i2c_start();		//transmit START condition
	i2c_write(0xD0);	//address DS1307 for write
	i2c_write(0);		//set register pointer to 0
	i2c_write(s);		//set seconds 
	i2c_write(m);		//set minutes 
	i2c_write(h);		//set hour 
	i2c_stop();		//transmit STOP condition
}

//************************************************************
void rtc_setDate(unsigned char y,unsigned char m,unsigned char d)
{
	i2c_start();		//transmit START condition
	i2c_write(0xD0);	//address DS1307 for write
	i2c_write(0x04);	//set register pointer to 4
	i2c_write(d);		//set day 
	i2c_write(m);		//set month
	i2c_write(y);		//set year 
	i2c_stop();		//transmit STOP condition
}

//************************************************************

void rtc_getTime(unsigned char *h,unsigned char *m,unsigned char *s)
{
	i2c_start();		//transmit START condition
	i2c_write(0xD0);		//address DS1307 for write
	i2c_write(0);		//set register pointer to 0
	i2c_stop();		//transmit STOP condition

	i2c_start();		//transmit START condition
	i2c_write(0xD1);		//address DS1307 for read
	*s = i2c_read(1);	//read second, return ACK
	*m = i2c_read(1);	//read minute, return ACK
	*h = i2c_read(0);	//read hour, return NACK
	i2c_stop();		//transmit STOP condition
}

//************************************************************

void rtc_getDate(unsigned char *y,unsigned char *m,unsigned char *d)
{
	i2c_start();		//transmit START condition
	i2c_write(0xD0);	//address DS1307 for write
	i2c_write(0x04);	//set register pointer to 4
	i2c_stop();			//transmit STOP condition

	i2c_start();		//transmit START condition
	i2c_write(0xD1);	//address DS1307 for read
	*d = i2c_read(1);	//read day, return ACK
	*m = i2c_read(1);	//read month, return ACK
	*y = i2c_read(0);	//read year, return NACK
	i2c_stop();			//transmit STOP condition
}

//************************************************************
void usart_init (void)
{
	UCSR0B = (1<<TXEN0);
	UCSR0C = (1<< UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;	//baud rate = 9600 (for 16MHz)
}

//************************************************************
void usart_sendByte (unsigned char ch)
{
	while (!(UCSR0A&(1<<UDRE0))); //wait until UDR0 is empty
	UDR0 = ch;					//transmit ch
}

//************************************************************
void usart_sendPackedBCD( unsigned char data )
{
	usart_sendByte('0'+ (data>>4));
	usart_sendByte('0'+ (data & 0x0F));	
}

//*************************************************************
