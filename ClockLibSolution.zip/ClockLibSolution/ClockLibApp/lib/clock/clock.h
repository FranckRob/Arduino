/*
 * clock.h
 *
 * Created: 3/15/2022 3:39:24 PM
 * Author : FRANCOIS ROBICHAUD
 */ 

unsigned char year,month,day,hour,min,sec;

void i2c_stop();

void i2c_write(unsigned char data);

unsigned char i2c_read(unsigned char ackVal);

void i2c_start(void);

void i2c_init(void);

void rtc_init(void);

void rtc_setTime(unsigned char h,unsigned char m,unsigned char s);

void rtc_setDate(unsigned char y,unsigned char m,unsigned char d);

void rtc_getTime(unsigned char *h,unsigned char *m,unsigned char *s);

void rtc_getDate(unsigned char *y,unsigned char *m,unsigned char *d);

void usart_init (void);

void usart_sendByte (unsigned char ch);

void usart_sendPackedBCD( unsigned char data );