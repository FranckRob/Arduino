/*
 * IntAppName.c
 *
 * Created: 4/13/2022 3:14:02 PM
 * Author : FRANCOIS ROBICHAUD
 */ 

#include "avr/io.h"
#include "avr/interrupt.h"
int compteur = 0;               // global counter for Timer 0 to get 1 second delay

int main ( )
{
	DDRB |= (1<<1)|(1<<3);		//make DDRB.1 and DDRB.3 output
	DDRC = 0x00;				//make PORTC input
	PORTC = 0xFF;				//enable pull-up
	DDRD = 0xFF;				//make PORTD output

	TCNT0 = -254;
	TCCR0A = 0x00;
	TCCR0B = 0x05;				//Normal mode, int clk, clk divider=1024

	TCNT1H = (-32000)>>8;		//the high byte
	TCNT1L = (-32000);			//the low byte
	TCCR1A = 0x00;
	TCCR1B = 0x05;				//clk divider=1024
	
	TIMSK0 = (1<<TOIE0);		//enable Timers 0 interrupt
	TIMSK1 = (1<<TOIE1);		//enable Timers 1 interrupt
	sei ();						//enable interrupts

	while (1)					//wait here
		PORTD = PINC;
}

ISR (TIMER0_OVF_vect)			//ISR for Timer0 overflow
{
	TCNT0 = -254;	   			//TCNT0 = -254 (reload for next round)
	compteur ++;
	if (compteur == 62)         //for approximately 1 second delay
	{
		PORTB ^= (1<<1);	   	//toggle PORTB.1
		compteur = 0;           //reset counter for next round
	}
}

ISR (TIMER1_OVF_vect)	   		//ISR for Timer0 overflow
{
	TCNT1H = (-32000)>>8;
	TCNT1L = (-32000);			//TCNT1 = -320000 (reload for next round)

	PORTB ^= (1<<3);			//toggle PORTB.3
}